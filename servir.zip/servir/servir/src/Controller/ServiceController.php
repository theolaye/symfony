<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\Article;
use App\Entity\Employe;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\Type;
use App\ Repository\ ArticleRepository;
use Doctrine\Common\Persistence\ObjectManager;

class ServiceController extends AbstractController
{
    /**
     * @Route("/service", name="service")
     */
    public function index()
    {
        return $this->render('service/index.html.twig', [
            'controller_name' => 'ServiceController',
        ]);
    }

/**
 * @Route("/", name="home")
 */
    public function home(){
        return $this->render('service/home.html.twig',[
            'title'=>"Dalal Ak Jaam",
            'age'=>25
        ]);
        
    }
    /**
     * @Route("/service/create", name="create")
     */
    public function ajout(Request $request, ObjectManager $manager){
      $employe= new Employe();
      $form=$this->createFormBuilder($employe)
                ->add('matricule',TextType::class,[
                    'attr'=>[
                        'placeholder'=>"entrez votre matricule",
                        'class'=>'form-control'
                    ]
                ])
                ->add('nom',TextType::class,[
                    'attr'=>[
                        'placeholder'=>"entrez votre nom",
                        'class'=>'form-control'
                    ]
                ])
                ->add('prenom',TextType::class,[
                    'attr'=>[
                        'placeholder'=>"entrez votre prénom",
                        'class'=>'form-control'
                    ]
                ])
                ->add('email',TextType::class,[
                    'attr'=>[
                        'placeholder'=>"saisissez votre adresse mail",
                        'class'=>'form-control'
                    ]
                ])
                ->add('salaire',TextType::class,[
                    'attr'=>[
                        'placeholder'=>"indiquez le salaire",
                        'class'=>'form-control'
                    ]
                ])
                ->add('service',TextType::class,[
                    'attr'=>[
                        'placeholder'=>"indiquez le service de l'employé",
                        'class'=>'form-control'
                    ]
                ])
                ->add('service',TextType::class,[
                    'attr'=>[
                        'placeholder'=>"indiquez le numéro de l'employé",
                        'class'=>'form-control'
                    ]
                ])
                ->add('service',TextType::class,[
                    'attr'=>[
                        'placeholder'=>"indiquez la date de de l'employé",
                        'class'=>'form-control'
                    ]
                ])
                ->add('save', SubmitType::class,[
                    'label'=>'(Yokeu)'
                ])
                ->getForm();

$form->handleRequest($request);
dump($employe);
if($form->isSubmitted() && $form->isValid()){
    
    $manager->persist($employe);
    $manager->flush();
    return $this->redirectToRoute('service',['matricule'=>$employe->getMatricule()]);

}

        return $this->render('create.html.twig',[
            'form'=>$form->createView()
        ]);
    }
  
}
