<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\NdongoDaraRepository")
 */
class NdongoDara
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Tuur;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $Dara;

    /**
     * @ORM\Column(type="integer")
     */
    private $Att;

    /**
     * @ORM\Column(type="datetime")
     */
    private $createdAt;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTuur(): ?string
    {
        return $this->Tuur;
    }

    public function setTuur(string $Tuur): self
    {
        $this->Tuur = $Tuur;

        return $this;
    }

    public function getDara(): ?string
    {
        return $this->Dara;
    }

    public function setDara(string $Dara): self
    {
        $this->Dara = $Dara;

        return $this;
    }

    public function getAtt(): ?int
    {
        return $this->Att;
    }

    public function setAtt(int $Att): self
    {
        $this->Att = $Att;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }
}
