<?php

namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class MaintenanceFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
     for($i=1;$i<=10;$i++){
         
     }

        $manager->flush();
    }
}
