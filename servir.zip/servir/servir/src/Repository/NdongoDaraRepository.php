<?php

namespace App\Repository;

use App\Entity\NdongoDara;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method NdongoDara|null find($id, $lockMode = null, $lockVersion = null)
 * @method NdongoDara|null findOneBy(array $criteria, array $orderBy = null)
 * @method NdongoDara[]    findAll()
 * @method NdongoDara[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class NdongoDaraRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, NdongoDara::class);
    }

    // /**
    //  * @return NdongoDara[] Returns an array of NdongoDara objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('n')
            ->andWhere('n.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('n.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?NdongoDara
    {
        return $this->createQueryBuilder('n')
            ->andWhere('n.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
